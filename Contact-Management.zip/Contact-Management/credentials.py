# User Credentials
host = 'localhost'
user = 'root'
password = ''
database = 'contact_management'
