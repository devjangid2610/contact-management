color_1 = "deep sky blue"
color_2 = "gray95"
color_3 = "black"
color_4 = "white"
color_5 = "red"
color_6 = "green3"
font_1 = "times new roman"
font_2 = "helvetica"

columns = ('first_name', 'last_name', 'address', 'contact', 'email')